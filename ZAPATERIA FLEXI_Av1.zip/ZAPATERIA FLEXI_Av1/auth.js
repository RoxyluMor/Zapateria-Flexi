// Lista de usuarios válidos (simulada)
const validUsers = [
    { username: "admin", password: "1234", isAdmin: true }, // Usuario administrador
    { username: "usuario1", password: "1234", isAdmin: false }, // Usuario normal
];

// Función para manejar el inicio de sesión
function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Buscar el usuario en la lista de usuarios válidos
    const user = validUsers.find(
        (u) => u.username === username && u.password === password
    );

    if (user) {
        alert("Inicio de sesión exitoso. Redirigiendo...");
        if (user.isAdmin) {
            window.location.href = "PrincipalAdmin.html"; // Redirige a la página de administrador
        } else {
            window.location.href = "Principal.html"; // Redirige a la página de usuario normal
        }
    } else {
        alert("Usuario o contraseña incorrectos. Inténtalo de nuevo.");
    }
}

// Función para manejar el registro de nuevos usuarios
function register() {
    const name = document.getElementById("reg-name").value;
    const lastname = document.getElementById("reg-lastname").value;
    const email = document.getElementById("reg-email").value;
    const password = document.getElementById("reg-password").value;
    const confirmPassword = document.getElementById("reg-confirm-password").value;

    // Validar que las contraseñas coincidan
    if (password !== confirmPassword) {
        alert("Las contraseñas no coinciden. Inténtalo de nuevo.");
        return;
    }

    // Crear un nuevo usuario (simulación)
    const newUser = {
        username: email, // Usamos el correo como nombre de usuario
        password: password,
        isAdmin: false, // Por defecto, los nuevos usuarios no son administradores
    };

    // Agregar el nuevo usuario a la lista de usuarios válidos
    validUsers.push(newUser);

    alert("Registro exitoso. Ahora puedes iniciar sesión.");
    window.location.href = "Principal.html"; // Redirige a la página de usuario normal
}