document.addEventListener("DOMContentLoaded", function () {
    const carouselItems = document.querySelectorAll(".carousel-item");
    const prevButton = document.querySelector(".carousel-control.prev");
    const nextButton = document.querySelector(".carousel-control.next");
    let currentIndex = 0;

    function showImage(index) {
        // Oculta todas las imágenes
        carouselItems.forEach(item => item.classList.remove("active"));

        // Muestra la imagen en el índice especificado
        carouselItems[index].classList.add("active");
    }

    function showNextImage() {
        currentIndex = (currentIndex + 1) % carouselItems.length;
        showImage(currentIndex);
    }

    function showPrevImage() {
        currentIndex = (currentIndex - 1 + carouselItems.length) % carouselItems.length;
        showImage(currentIndex);
    }

    // Cambia la imagen cada 15 segundos
    setInterval(showNextImage, 10000);

    // Eventos para las flechas
    prevButton.addEventListener("click", showPrevImage);
    nextButton.addEventListener("click", showNextImage);
});